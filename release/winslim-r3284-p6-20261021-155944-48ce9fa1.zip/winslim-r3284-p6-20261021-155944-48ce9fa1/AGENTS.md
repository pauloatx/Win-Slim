# Rotina de desenvolvimento do Win-Slim

## Correções de bugs: gate obrigatório de regressão
Para cada bug corrigido, o desenvolvedor deve:
1. Registrar um identificador estável, o cenário que reproduz o defeito e o comportamento esperado em tests/regression/cases.json.
2. Criar ou ampliar um teste automatizado comportamental que falhe com o defeito e passe com a correção. Reutilizar um teste existente só quando o cenário do bug estiver efetivamente coberto. Quando viável, executar o teste antes da correção para demonstrar a falha; se não for possível, documentar essa limitação.
3. Testar o cenário corrigido, sua falha de entrada/indisponibilidade e preservação do estado relacionado. Evitar testes que apenas procuram strings no código.
4. Executar Validar-Regressoes.bat antes de empacotar a entrega. O gate retorna código diferente de zero quando há falhas, configuração inválida ou ausência dos testes exigidos.
5. Corrigir a causa; nunca remover, enfraquecer ou atualizar expectativas apenas para esconder uma falha.
6. Preservar testes antigos e os contratos de backup, Apply, Verify e Undo.
7. Na entrega, informar os testes executados e as limitações. Sem Windows/WPF, classificar os testes nativos como pendentes, nunca aprovados.

O script executa os casos cadastrados; a elaboração do teste para cada novo bug é responsabilidade do desenvolvedor. Ele não deduz bugs nem cria testes úteis automaticamente a partir de alterações arbitrárias.

## Base e compatibilidade
Interface C#/WPF com backend PowerShell 5.1. Preservar o visual aprovado. Não retomar Rust. Não aplicar otimizações no computador do desenvolvedor durante regressões; usar fixtures descartáveis ou simulação. Alterações reais de produção exigem o fluxo normal de revisão e backup do aplicativo.

## Empacotamento
Antes de publicar um ZIP, executar os testes Python do empacotador e usar tools/package_release.py para validar cadastro unico de regressoes, scripts e hashes. Nao montar arquivos de entrega por append de casos sem checar unicidade. Python e ferramenta de desenvolvimento; nao e requisito para executar o app no Windows.

## Fluxo acelerado de entrega (R3.2.83 em diante)
- Consolidar requisitos em lotes por familia/risco e uma unica candidata; nao criar release para cada tweak. Congelar escopo antes da estabilizacao.
- Durante desenvolvimento, executar testes do componente alterado; na candidata, exigir todo o cadastro e o self-test WPF. Cada bug continua com regressao comportamental.
- Iniciar-Validacao.bat e o ponto de entrada de aceite tecnico: gate completo, diagnostico automatico e abertura somente apos sucesso completo. O gate integrado delega dez suites ao harness, sem execucao duplicada. Execucao isolada da suite nativa continua completa.
- Resultados vazios, parciais, duplicados ou de outra execucao nunca autorizam progressao. Falha bloqueia abertura pelo pipeline, coleta evidencia e exige correcao.
- Usuario valida somente efeitos reais novos/alterados por familia, em lote; nao repetir manualmente lotes anteriores aprovados sem regressao ou mudanca relacionada. Coletar-Diagnostico.bat gera um ZIP com resultados/backups e resumos de benchmarks.
- CI Windows esta preparada no workflow; enquanto nao executada, marcar pendente. Nao publicar automaticamente nem rotular producao aprovada sem verificacoes Windows e aceite real do escopo.
- PresentMon e opcional, acionado pelo usuario, binario oficial fixado por SHA-256 e licencas preservadas. Captura nao aplica ajustes e so encerra sua sessao ETW exclusiva. Nunca usar stop global, autoelevacao ou instalar servico/driver silenciosamente.
